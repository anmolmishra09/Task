# Design Guidelines for Scalable Web App with Authentication & Dashboard

## Design Approach
**Reference-Based Approach** - Drawing inspiration from modern productivity applications like Linear, Notion, and Vercel Dashboard for clean, professional aesthetics that prioritize functionality and user experience.

## Core Design Elements

### A. Color Palette
**Light Mode:**
- Primary: 244 63% 20% (Deep blue)
- Background: 0 0% 98% (Near white)
- Surface: 0 0% 100% (Pure white)
- Text Primary: 220 13% 18% (Dark charcoal)
- Text Secondary: 220 9% 46% (Medium gray)
- Border: 220 13% 91% (Light gray)

**Dark Mode:**
- Primary: 217 91% 60% (Bright blue)
- Background: 224 71% 4% (Very dark blue)
- Surface: 224 64% 8% (Dark blue-gray)
- Text Primary: 210 40% 95% (Near white)
- Text Secondary: 215 20% 65% (Light gray)
- Border: 216 34% 17% (Dark border)

### B. Typography
- **Primary Font:** Inter (Google Fonts)
- **Headings:** Font weights 600-700, sizes from text-lg to text-3xl
- **Body Text:** Font weight 400-500, text-sm to text-base
- **Code/Technical:** JetBrains Mono for any code snippets or technical data

### C. Layout System
**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, and 12 consistently
- Small gaps: `gap-2` (8px)
- Medium spacing: `p-4`, `m-6` (16px, 24px)
- Large sections: `py-8`, `px-12` (32px, 48px)

### D. Component Library

**Navigation:**
- Clean header with logo, navigation links, and user avatar
- Sidebar navigation for dashboard with collapsible menu
- Breadcrumb navigation for deeper pages

**Forms:**
- Clean input fields with subtle borders and focus states
- Floating labels or clear placeholder text
- Inline validation with gentle error states
- Primary buttons with rounded corners (rounded-md)

**Data Display:**
- Card-based layouts with subtle shadows
- Clean tables with alternating row backgrounds
- Status badges with appropriate color coding
- Empty states with helpful illustrations or icons

**Dashboard Elements:**
- Statistics cards with subtle gradients
- Clean data visualization areas
- Action buttons strategically placed
- Quick access panels for common tasks

**Authentication Pages:**
- Centered forms on clean backgrounds
- Subtle branding elements
- Clear calls-to-action
- Progressive disclosure for complex flows

### E. Interaction Patterns
- Subtle hover states with gentle transitions
- Loading states with skeleton screens
- Toast notifications for user feedback
- Modal dialogs for critical actions
- Smooth page transitions

## Visual Hierarchy
- Use typography scale and color contrast for clear information hierarchy
- White space as a design element to create breathing room
- Strategic use of shadows and borders to define content areas
- Consistent icon usage throughout the interface

## Responsive Considerations
- Mobile-first approach with clean stack layouts
- Collapsible navigation for smaller screens
- Touch-friendly interactive elements
- Optimized form layouts for mobile input

This design system prioritizes clarity, professionalism, and user productivity while maintaining visual appeal appropriate for a modern web application with authentication and dashboard functionality.