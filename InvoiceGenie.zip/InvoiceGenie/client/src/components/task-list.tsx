import { Task } from "@shared/schema"
import { TaskCard } from "./task-card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Filter } from "lucide-react"

interface TaskListProps {
  tasks: Task[]
  isLoading?: boolean
  onCreateTask: () => void
  onEditTask: (task: Task) => void
  onDeleteTask: (task: Task) => void
  onToggleComplete: (task: Task) => void
  filterStatus: string
  onFilterChange: (status: string) => void
  sortBy: string
  onSortChange: (sort: string) => void
}

export function TaskList({
  tasks,
  isLoading = false,
  onCreateTask,
  onEditTask,
  onDeleteTask,
  onToggleComplete,
  filterStatus,
  onFilterChange,
  sortBy,
  onSortChange
}: TaskListProps) {
  // Filter tasks based on status
  const filteredTasks = tasks.filter(task => {
    if (filterStatus === "all") return true
    return task.status === filterStatus
  })

  // Sort tasks
  const sortedTasks = [...filteredTasks].sort((a, b) => {
    switch (sortBy) {
      case "created-desc":
        return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
      case "created-asc":
        return new Date(a.createdAt || 0).getTime() - new Date(b.createdAt || 0).getTime()
      case "priority":
        const priorityOrder = { high: 3, medium: 2, low: 1 }
        return (priorityOrder[b.priority as keyof typeof priorityOrder] || 0) - 
               (priorityOrder[a.priority as keyof typeof priorityOrder] || 0)
      case "title":
        return a.title.localeCompare(b.title)
      default:
        return new Date(b.updatedAt || b.createdAt || 0).getTime() - 
               new Date(a.updatedAt || a.createdAt || 0).getTime()
    }
  })

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-4">
            <div className="h-10 w-24 bg-muted animate-pulse rounded" />
            <div className="h-10 w-32 bg-muted animate-pulse rounded" />
          </div>
          <div className="h-10 w-28 bg-muted animate-pulse rounded" />
        </div>
        <div className="grid gap-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-32 bg-muted animate-pulse rounded-lg" />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <Select value={filterStatus} onValueChange={onFilterChange}>
              <SelectTrigger className="w-32" data-testid="select-filter-status">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Tasks</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="in-progress">In Progress</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Select value={sortBy} onValueChange={onSortChange}>
            <SelectTrigger className="w-40" data-testid="select-sort-by">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="updated-desc">Recently Updated</SelectItem>
              <SelectItem value="created-desc">Recently Created</SelectItem>
              <SelectItem value="created-asc">Oldest First</SelectItem>
              <SelectItem value="priority">Priority</SelectItem>
              <SelectItem value="title">Alphabetical</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <Button onClick={onCreateTask} data-testid="button-create-new-task">
          <Plus className="h-4 w-4 mr-2" />
          New Task
        </Button>
      </div>
      
      {/* Task Grid */}
      {sortedTasks.length === 0 ? (
        <div className="text-center py-12" data-testid="empty-task-state">
          <div className="mx-auto w-24 h-24 bg-muted rounded-full flex items-center justify-center mb-4">
            <Plus className="h-12 w-12 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold mb-2">
            {filterStatus === "all" ? "No tasks yet" : `No ${filterStatus.replace("-", " ")} tasks`}
          </h3>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            {filterStatus === "all" 
              ? "Get started by creating your first task. Organize your work and stay productive."
              : `You don't have any ${filterStatus.replace("-", " ")} tasks at the moment.`
            }
          </p>
          <Button onClick={onCreateTask} data-testid="button-create-first-task">
            <Plus className="h-4 w-4 mr-2" />
            Create Your First Task
          </Button>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {sortedTasks.map(task => (
            <TaskCard
              key={task.id}
              task={task}
              onEdit={onEditTask}
              onDelete={onDeleteTask}
              onToggleComplete={onToggleComplete}
            />
          ))}
        </div>
      )}
    </div>
  )
}