import { Task } from "@shared/schema"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { 
  MoreHorizontal, 
  Edit3, 
  Trash2, 
  CheckCircle2, 
  Circle, 
  Clock,
  AlertTriangle,
  Flag
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"

interface TaskCardProps {
  task: Task
  onEdit?: (task: Task) => void
  onDelete?: (task: Task) => void
  onToggleComplete?: (task: Task) => void
  onUpdateStatus?: (task: Task, status: "pending" | "in-progress" | "completed") => void
}

export function TaskCard({ 
  task, 
  onEdit, 
  onDelete, 
  onToggleComplete, 
  onUpdateStatus 
}: TaskCardProps) {
  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case "high":
        return <AlertTriangle className="h-3 w-3" />
      case "medium":
        return <Flag className="h-3 w-3" />
      case "low":
        return <Clock className="h-3 w-3" />
      default:
        return <Clock className="h-3 w-3" />
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "destructive"
      case "medium":
        return "default"
      case "low":
        return "secondary"
      default:
        return "secondary"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400"
      case "in-progress":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400"
      case "pending":
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
    }
  }

  const formatDate = (date: Date | null) => {
    if (!date) return ""
    return new Date(date).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric"
    })
  }

  return (
    <Card 
      className={cn(
        "hover-elevate transition-all duration-200",
        task.completed && "opacity-75"
      )}
      data-testid={`card-task-${task.id}`}
    >
      <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
        <div className="flex items-start gap-3 flex-1">
          <Button
            variant="ghost"
            size="sm"
            className="h-6 w-6 p-0 mt-1"
            onClick={() => onToggleComplete?.(task)}
            data-testid={`button-toggle-task-${task.id}`}
          >
            {task.completed ? (
              <CheckCircle2 className="h-4 w-4 text-green-600" />
            ) : (
              <Circle className="h-4 w-4 text-muted-foreground" />
            )}
          </Button>
          <div className="flex-1 min-w-0">
            <h3 
              className={cn(
                "font-semibold text-sm leading-tight",
                task.completed && "line-through text-muted-foreground"
              )}
              data-testid={`text-task-title-${task.id}`}
            >
              {task.title}
            </h3>
            {task.description && (
              <p 
                className="text-xs text-muted-foreground mt-1 line-clamp-2"
                data-testid={`text-task-description-${task.id}`}
              >
                {task.description}
              </p>
            )}
          </div>
        </div>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0"
              data-testid={`button-task-menu-${task.id}`}
            >
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem 
              onClick={() => onEdit?.(task)}
              data-testid={`button-edit-task-${task.id}`}
            >
              <Edit3 className="mr-2 h-4 w-4" />
              Edit
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              className="text-destructive"
              onClick={() => onDelete?.(task)}
              data-testid={`button-delete-task-${task.id}`}
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>
      
      <CardFooter className="pt-0 flex flex-wrap items-center gap-2 text-xs">
        <Badge 
          variant={getPriorityColor(task.priority) as any}
          className="flex items-center gap-1"
          data-testid={`badge-priority-${task.id}`}
        >
          {getPriorityIcon(task.priority)}
          {task.priority}
        </Badge>
        
        <Badge 
          className={getStatusColor(task.status)}
          data-testid={`badge-status-${task.id}`}
        >
          {task.status.replace("-", " ")}
        </Badge>
        
        {task.updatedAt && (
          <span className="text-muted-foreground ml-auto" data-testid={`text-task-date-${task.id}`}>
            {formatDate(task.updatedAt)}
          </span>
        )}
      </CardFooter>
    </Card>
  )
}