import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { updateUserSchema, type UpdateUser, type User } from "@shared/schema"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Save, User2 } from "lucide-react"
import { useEffect } from "react"

interface ProfileFormProps {
  user: User
  onSubmit: (data: UpdateUser) => Promise<void>
  isLoading?: boolean
  error?: string
  successMessage?: string
}

export function ProfileForm({ user, onSubmit, isLoading = false, error, successMessage }: ProfileFormProps) {
  const form = useForm<UpdateUser>({
    resolver: zodResolver(updateUserSchema),
    defaultValues: {
      name: user.name,
      email: user.email,
    },
  })

  // Reset form when user data changes
  useEffect(() => {
    form.reset({
      name: user.name,
      email: user.email,
    })
  }, [user, form])

  const handleSubmit = async (data: UpdateUser) => {
    try {
      await onSubmit(data)
    } catch (err) {
      console.error("Profile update failed:", err)
    }
  }

  const hasChanges = form.watch("name") !== user.name || form.watch("email") !== user.email

  return (
    <Card className="w-full max-w-2xl" data-testid="card-profile-form">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <User2 className="h-5 w-5" />
          Profile Settings
        </CardTitle>
        <CardDescription>
          Update your personal information and account details
        </CardDescription>
      </CardHeader>
      
      <form onSubmit={form.handleSubmit(handleSubmit)}>
        <CardContent className="space-y-6">
          {error && (
            <Alert variant="destructive" data-testid="alert-profile-error">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          {successMessage && (
            <Alert className="border-green-200 bg-green-50 text-green-800 dark:border-green-800 dark:bg-green-900/20 dark:text-green-400" data-testid="alert-profile-success">
              <AlertDescription>{successMessage}</AlertDescription>
            </Alert>
          )}
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                type="text"
                placeholder="Enter your full name"
                data-testid="input-profile-name"
                {...form.register("name")}
              />
              {form.formState.errors.name && (
                <p className="text-sm text-destructive" data-testid="error-profile-name">
                  {form.formState.errors.name.message}
                </p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter your email"
                data-testid="input-profile-email"
                {...form.register("email")}
              />
              {form.formState.errors.email && (
                <p className="text-sm text-destructive" data-testid="error-profile-email">
                  {form.formState.errors.email.message}
                </p>
              )}
            </div>
          </div>
          
          <div className="space-y-2">
            <Label>Username</Label>
            <Input
              value={user.username}
              disabled
              className="bg-muted"
              data-testid="input-profile-username-readonly"
            />
            <p className="text-xs text-muted-foreground">
              Username cannot be changed
            </p>
          </div>
          
          <div className="space-y-2">
            <Label>Account Created</Label>
            <Input
              value={user.createdAt ? new Date(user.createdAt).toLocaleDateString("en-US", {
                year: "numeric",
                month: "long", 
                day: "numeric"
              }) : "N/A"}
              disabled
              className="bg-muted"
              data-testid="input-profile-created-readonly"
            />
          </div>
        </CardContent>
        
        <CardFooter className="flex justify-between">
          <div className="text-sm text-muted-foreground">
            {hasChanges ? "You have unsaved changes" : "No changes made"}
          </div>
          
          <Button 
            type="submit" 
            disabled={isLoading || !hasChanges}
            data-testid="button-save-profile"
          >
            {isLoading ? (
              <>
                <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-r-transparent" />
                Saving...
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </>
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}