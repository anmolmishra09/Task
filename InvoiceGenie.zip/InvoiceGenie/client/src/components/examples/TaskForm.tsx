import { TaskForm } from '../task-form'
import { useState } from 'react'
import { Button } from '@/components/ui/button'

export default function TaskFormExample() {
  const [isOpen, setIsOpen] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [loading, setLoading] = useState(false)

  // todo: remove mock functionality
  const sampleTask = {
    id: "1",
    title: "Sample Task",
    description: "This is a sample task description for editing demonstration",
    status: "in-progress" as const,
    priority: "high" as const,
    userId: "user1",
    completed: false,
    createdAt: new Date("2024-01-15"),
    updatedAt: new Date("2024-01-16")
  }

  const handleSubmit = async (data: any) => {
    setLoading(true)
    console.log('Task form submitted:', data)
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    console.log('Task saved successfully!')
    setLoading(false)
  }

  const openCreateForm = () => {
    setIsEditing(false)
    setIsOpen(true)
  }

  const openEditForm = () => {
    setIsEditing(true)
    setIsOpen(true)
  }

  const handleClose = () => {
    setIsOpen(false)
    setLoading(false)
  }

  return (
    <div className="p-6 bg-background">
      <h2 className="text-xl font-semibold mb-4">Task Form Components</h2>
      <div className="space-y-4">
        <Button onClick={openCreateForm}>Create New Task</Button>
        <Button variant="outline" onClick={openEditForm}>Edit Sample Task</Button>
      </div>
      
      <TaskForm
        isOpen={isOpen}
        onClose={handleClose}
        onSubmit={handleSubmit}
        task={isEditing ? sampleTask : null}
        isLoading={loading}
      />
    </div>
  )
}