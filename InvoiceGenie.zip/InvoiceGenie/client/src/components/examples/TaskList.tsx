import { TaskList } from '../task-list'
import { useState } from 'react'

export default function TaskListExample() {
  const [filterStatus, setFilterStatus] = useState("all")
  const [sortBy, setSortBy] = useState("updated-desc")

  // todo: remove mock functionality
  const sampleTasks = [
    {
      id: "1",
      title: "Complete project documentation",
      description: "Write comprehensive documentation for the TaskFlow application including API docs and user guide. This is a longer description to test text wrapping.",
      status: "in-progress" as const,
      priority: "high" as const,
      userId: "user1",
      completed: false,
      createdAt: new Date("2024-01-15"),
      updatedAt: new Date("2024-01-16")
    },
    {
      id: "2",
      title: "Review pull requests",
      description: "Review and approve pending pull requests from the development team",
      status: "pending" as const,
      priority: "medium" as const,
      userId: "user1",
      completed: false,
      createdAt: new Date("2024-01-14"),
      updatedAt: new Date("2024-01-14")
    },
    {
      id: "3",
      title: "Fix critical authentication bug",
      description: "Resolve the login issue affecting premium users",
      status: "pending" as const,
      priority: "high" as const,
      userId: "user1",
      completed: false,
      createdAt: new Date("2024-01-13"),
      updatedAt: new Date("2024-01-13")
    },
    {
      id: "4",
      title: "Update dependencies",
      description: null,
      status: "completed" as const,
      priority: "low" as const,
      userId: "user1",
      completed: true,
      createdAt: new Date("2024-01-10"),
      updatedAt: new Date("2024-01-12")
    },
    {
      id: "5",
      title: "Refactor authentication system",
      description: "Improve the current authentication system for better security",
      status: "completed" as const,
      priority: "medium" as const,
      userId: "user1",
      completed: true,
      createdAt: new Date("2024-01-08"),
      updatedAt: new Date("2024-01-11")
    }
  ]

  const handleCreateTask = () => {
    console.log('Create task clicked')
  }

  const handleEditTask = (task: any) => {
    console.log('Edit task:', task.title)
  }

  const handleDeleteTask = (task: any) => {
    console.log('Delete task:', task.title)
  }

  const handleToggleComplete = (task: any) => {
    console.log('Toggle complete for:', task.title)
  }

  return (
    <div className="p-6 bg-background min-h-screen">
      <h2 className="text-2xl font-semibold mb-6">Task List Component</h2>
      <TaskList
        tasks={sampleTasks}
        onCreateTask={handleCreateTask}
        onEditTask={handleEditTask}
        onDeleteTask={handleDeleteTask}
        onToggleComplete={handleToggleComplete}
        filterStatus={filterStatus}
        onFilterChange={setFilterStatus}
        sortBy={sortBy}
        onSortChange={setSortBy}
      />
    </div>
  )
}