import { ProfileForm } from '../profile-form'
import { useState } from 'react'

export default function ProfileFormExample() {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [successMessage, setSuccessMessage] = useState("")

  // todo: remove mock functionality
  const mockUser = {
    id: "1",
    name: "John Doe",
    username: "johndoe",
    email: "john.doe@example.com",
    password: "hidden",
    createdAt: new Date("2024-01-01")
  }

  const handleSubmit = async (data: any) => {
    setLoading(true)
    setError("")
    setSuccessMessage("")
    
    console.log('Profile update attempt with:', data)
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    // Simulate error occasionally
    if (data.email === "error@test.com") {
      setError("Email address is already in use")
      setLoading(false)
      return
    }
    
    setSuccessMessage("Profile updated successfully!")
    console.log('Profile update successful!')
    setLoading(false)
    
    // Clear success message after 3 seconds
    setTimeout(() => setSuccessMessage(""), 3000)
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <ProfileForm
        user={mockUser}
        onSubmit={handleSubmit}
        isLoading={loading}
        error={error}
        successMessage={successMessage}
      />
    </div>
  )
}