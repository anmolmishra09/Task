import { DashboardHeader } from '../dashboard-header'
import { ThemeProvider } from '../theme-provider'
import { useState } from 'react'

export default function DashboardHeaderExample() {
  const [searchQuery, setSearchQuery] = useState("")

  // todo: remove mock functionality
  const mockUser = {
    id: "1",
    name: "John Doe",
    username: "johndoe",
    email: "john.doe@example.com",
    password: "hidden",
    createdAt: new Date("2024-01-01")
  }

  const handleCreateTask = () => {
    console.log('Create task clicked')
  }

  const handleLogout = () => {
    console.log('Logout clicked')
  }

  return (
    <ThemeProvider>
      <div className="min-h-screen bg-background">
        <DashboardHeader
          user={mockUser}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          onCreateTask={handleCreateTask}
          onLogout={handleLogout}
        />
        <div className="p-6">
          <p className="text-muted-foreground">Current search: "{searchQuery}"</p>
        </div>
      </div>
    </ThemeProvider>
  )
}