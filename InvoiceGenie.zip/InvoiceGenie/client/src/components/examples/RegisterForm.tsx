import { RegisterForm } from '../register-form'
import { useState } from 'react'

export default function RegisterFormExample() {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const handleRegister = async (data: any) => {
    setLoading(true)
    setError("")
    console.log('Registration attempt with:', data)
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    // Simulate error occasionally
    if (data.username === "taken") {
      setError("Username already taken")
      setLoading(false)
      return
    }
    
    console.log('Registration successful!')
    setLoading(false)
  }

  const handleSwitchToLogin = () => {
    console.log('Switch to login triggered')
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <RegisterForm
        onSubmit={handleRegister}
        onSwitchToLogin={handleSwitchToLogin}
        isLoading={loading}
        error={error}
      />
    </div>
  )
}