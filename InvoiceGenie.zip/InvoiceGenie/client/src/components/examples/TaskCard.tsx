import { TaskCard } from '../task-card'

export default function TaskCardExample() {
  // todo: remove mock functionality
  const sampleTasks = [
    {
      id: "1",
      title: "Complete project documentation",
      description: "Write comprehensive documentation for the TaskFlow application including API docs and user guide",
      status: "in-progress" as const,
      priority: "high" as const,
      userId: "user1",
      completed: false,
      createdAt: new Date("2024-01-15"),
      updatedAt: new Date("2024-01-16")
    },
    {
      id: "2", 
      title: "Review pull requests",
      description: "Review and approve pending pull requests from the development team",
      status: "pending" as const,
      priority: "medium" as const,
      userId: "user1", 
      completed: false,
      createdAt: new Date("2024-01-14"),
      updatedAt: new Date("2024-01-14")
    },
    {
      id: "3",
      title: "Update dependencies",
      description: null,
      status: "completed" as const,
      priority: "low" as const,
      userId: "user1",
      completed: true,
      createdAt: new Date("2024-01-10"),
      updatedAt: new Date("2024-01-12")
    }
  ]

  const handleEdit = (task: any) => {
    console.log('Edit task:', task.title)
  }

  const handleDelete = (task: any) => {
    console.log('Delete task:', task.title)
  }

  const handleToggleComplete = (task: any) => {
    console.log('Toggle complete for:', task.title)
  }

  return (
    <div className="p-6 space-y-4 bg-background">
      <h2 className="text-xl font-semibold mb-4">Task Cards</h2>
      <div className="grid gap-4 max-w-md">
        {sampleTasks.map(task => (
          <TaskCard
            key={task.id}
            task={task}
            onEdit={handleEdit}
            onDelete={handleDelete}
            onToggleComplete={handleToggleComplete}
          />
        ))}
      </div>
    </div>
  )
}