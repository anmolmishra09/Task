import { LoginForm } from '../login-form'
import { useState } from 'react'

export default function LoginFormExample() {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const handleLogin = async (data: any) => {
    setLoading(true)
    setError("")
    console.log('Login attempt with:', data)
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    // Simulate error occasionally 
    if (data.username === "error") {
      setError("Invalid username or password")
      setLoading(false)
      return
    }
    
    console.log('Login successful!')
    setLoading(false)
  }

  const handleSwitchToRegister = () => {
    console.log('Switch to register triggered')
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <LoginForm
        onSubmit={handleLogin}
        onSwitchToRegister={handleSwitchToRegister}
        isLoading={loading}
        error={error}
      />
    </div>
  )
}