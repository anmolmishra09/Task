import { TaskStats } from '../task-stats'

export default function TaskStatsExample() {
  // todo: remove mock functionality
  const sampleTasks = [
    {
      id: "1",
      title: "Complete project documentation",
      description: "Write comprehensive documentation",
      status: "completed" as const,
      priority: "high" as const,
      userId: "user1",
      completed: true,
      createdAt: new Date("2024-01-15"),
      updatedAt: new Date("2024-01-16")
    },
    {
      id: "2",
      title: "Review pull requests", 
      description: "Review pending PRs",
      status: "in-progress" as const,
      priority: "medium" as const,
      userId: "user1",
      completed: false,
      createdAt: new Date("2024-01-14"),
      updatedAt: new Date("2024-01-14")
    },
    {
      id: "3",
      title: "Fix critical bug",
      description: "High priority bug fix",
      status: "pending" as const,
      priority: "high" as const,
      userId: "user1",
      completed: false,
      createdAt: new Date("2024-01-13"),
      updatedAt: new Date("2024-01-13")
    },
    {
      id: "4",
      title: "Update dependencies",
      description: null,
      status: "completed" as const,
      priority: "low" as const,
      userId: "user1",
      completed: true,
      createdAt: new Date("2024-01-10"),
      updatedAt: new Date("2024-01-12")
    },
    {
      id: "5",
      title: "Refactor authentication",
      description: "Improve auth system",
      status: "pending" as const,
      priority: "medium" as const,
      userId: "user1",
      completed: false,
      createdAt: new Date("2024-01-12"),
      updatedAt: new Date("2024-01-12")
    }
  ]

  return (
    <div className="p-6 bg-background">
      <h2 className="text-xl font-semibold mb-6">Task Statistics</h2>
      <TaskStats tasks={sampleTasks} />
    </div>
  )
}