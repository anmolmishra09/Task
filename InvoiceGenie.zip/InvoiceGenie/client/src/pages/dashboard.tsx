import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { TaskStats } from "@/components/task-stats"
import { TaskList } from "@/components/task-list"
import { TaskForm } from "@/components/task-form"
import { ProfileForm } from "@/components/profile-form"
import { useAuth } from "@/components/auth-context"
import { Task, InsertTask, UpdateTask, UpdateUser } from "@shared/schema"
import { useToast } from "@/hooks/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Settings } from "lucide-react"

export default function Dashboard() {
  const { user, logout } = useAuth()
  const { toast } = useToast()
  
  // Search and filtering state
  const [searchQuery, setSearchQuery] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [sortBy, setSortBy] = useState("updated-desc")
  
  // Task form state
  const [isTaskFormOpen, setIsTaskFormOpen] = useState(false)
  const [editingTask, setEditingTask] = useState<Task | null>(null)
  const [isTaskLoading, setIsTaskLoading] = useState(false)
  
  // Profile state
  const [isProfileLoading, setIsProfileLoading] = useState(false)
  const [profileError, setProfileError] = useState("")
  const [profileSuccess, setProfileSuccess] = useState("")
  
  // Tab state
  const [activeTab, setActiveTab] = useState("tasks")

  // TODO: Replace with actual API integration - remove mock functionality
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: "1",
      title: "Welcome to TaskFlow!",
      description: "This is your first task. You can edit, complete, or delete it.",
      status: "pending",
      priority: "medium",
      userId: user?.id || "",
      completed: false,
      createdAt: new Date("2024-01-15T10:00:00"),
      updatedAt: new Date("2024-01-15T10:00:00")
    },
    {
      id: "2",
      title: "Explore the dashboard features",
      description: "Take a look around the dashboard, try creating new tasks, and explore the filtering options.",
      status: "in-progress",
      priority: "low",
      userId: user?.id || "",
      completed: false,
      createdAt: new Date("2024-01-14T09:30:00"),
      updatedAt: new Date("2024-01-15T14:30:00")
    }
  ])

  if (!user) return null

  // Filter tasks based on search query
  const searchFilteredTasks = tasks.filter(task =>
    task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (task.description?.toLowerCase().includes(searchQuery.toLowerCase()) ?? false)
  )

  const handleCreateTask = () => {
    setEditingTask(null)
    setIsTaskFormOpen(true)
  }

  const handleEditTask = (task: Task) => {
    setEditingTask(task)
    setIsTaskFormOpen(true)
  }

  const handleTaskSubmit = async (data: InsertTask | UpdateTask) => {
    setIsTaskLoading(true)
    
    try {
      // TODO: Replace with actual API calls
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      if (editingTask) {
        // Update existing task
        setTasks(prev => prev.map(task => 
          task.id === editingTask.id 
            ? { ...task, ...data, updatedAt: new Date() }
            : task
        ))
        toast({
          title: "Task updated!",
          description: "Your task has been successfully updated.",
        })
      } else {
        // Create new task
        const newTask: Task = {
          id: Date.now().toString(),
          ...data as InsertTask,
          description: (data as InsertTask).description || null,
          userId: user.id,
          completed: (data as InsertTask).status === "completed",
          createdAt: new Date(),
          updatedAt: new Date()
        }
        setTasks(prev => [newTask, ...prev])
        toast({
          title: "Task created!",
          description: "Your new task has been added successfully.",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save task. Please try again.",
        variant: "destructive"
      })
    } finally {
      setIsTaskLoading(false)
    }
  }

  const handleDeleteTask = async (task: Task) => {
    try {
      // TODO: Replace with actual API call
      await new Promise(resolve => setTimeout(resolve, 500))
      
      setTasks(prev => prev.filter(t => t.id !== task.id))
      toast({
        title: "Task deleted",
        description: "Task has been removed from your list.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete task. Please try again.",
        variant: "destructive"
      })
    }
  }

  const handleToggleComplete = async (task: Task) => {
    try {
      // TODO: Replace with actual API call
      await new Promise(resolve => setTimeout(resolve, 300))
      
      const newStatus = task.completed ? "pending" : "completed"
      setTasks(prev => prev.map(t => 
        t.id === task.id 
          ? { ...t, status: newStatus, completed: !task.completed, updatedAt: new Date() }
          : t
      ))
      
      toast({
        title: task.completed ? "Task reopened" : "Task completed!",
        description: task.completed 
          ? "Task has been marked as incomplete." 
          : "Great job completing this task!",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update task status. Please try again.",
        variant: "destructive"
      })
    }
  }

  const handleProfileUpdate = async (data: UpdateUser) => {
    setIsProfileLoading(true)
    setProfileError("")
    setProfileSuccess("")
    
    try {
      // TODO: Replace with actual API call
      console.log("Profile update:", data)
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      setProfileSuccess("Profile updated successfully!")
      
      toast({
        title: "Profile updated!",
        description: "Your profile information has been saved.",
      })
      
      // Clear success message after 3 seconds
      setTimeout(() => setProfileSuccess(""), 3000)
    } catch (error) {
      setProfileError("Failed to update profile. Please try again.")
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive"
      })
    } finally {
      setIsProfileLoading(false)
    }
  }

  const handleLogout = () => {
    logout()
    toast({
      title: "Signed out",
      description: "You have been successfully signed out.",
    })
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader
        user={user}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onCreateTask={handleCreateTask}
        onLogout={handleLogout}
      />
      
      <div className="container mx-auto p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="tasks" data-testid="tab-tasks">Tasks</TabsTrigger>
            <TabsTrigger value="profile" data-testid="tab-profile">
              <Settings className="h-4 w-4 mr-2" />
              Profile
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="tasks" className="space-y-6 mt-6">
            <div>
              <h1 className="text-3xl font-bold">Welcome back, {user.name}!</h1>
              <p className="text-muted-foreground mt-1">
                Here's an overview of your tasks and productivity.
              </p>
            </div>
            
            <TaskStats tasks={searchFilteredTasks} />
            
            <TaskList
              tasks={searchFilteredTasks}
              onCreateTask={handleCreateTask}
              onEditTask={handleEditTask}
              onDeleteTask={handleDeleteTask}
              onToggleComplete={handleToggleComplete}
              filterStatus={filterStatus}
              onFilterChange={setFilterStatus}
              sortBy={sortBy}
              onSortChange={setSortBy}
            />
          </TabsContent>
          
          <TabsContent value="profile" className="mt-6">
            <div className="flex justify-center">
              <ProfileForm
                user={user}
                onSubmit={handleProfileUpdate}
                isLoading={isProfileLoading}
                error={profileError}
                successMessage={profileSuccess}
              />
            </div>
          </TabsContent>
        </Tabs>
      </div>
      
      <TaskForm
        isOpen={isTaskFormOpen}
        onClose={() => {
          setIsTaskFormOpen(false)
          setEditingTask(null)
        }}
        onSubmit={handleTaskSubmit}
        task={editingTask}
        isLoading={isTaskLoading}
      />
    </div>
  )
}