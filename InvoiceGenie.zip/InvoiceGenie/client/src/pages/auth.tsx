import { useState } from "react"
import { LoginForm } from "@/components/login-form"
import { RegisterForm } from "@/components/register-form"
import { useAuth } from "@/components/auth-context"
import { LoginUser, InsertUser } from "@shared/schema"
import { useToast } from "@/hooks/use-toast"

export default function Auth() {
  const [isLogin, setIsLogin] = useState(true)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const { login } = useAuth()
  const { toast } = useToast()

  const handleLogin = async (data: LoginUser) => {
    setIsLoading(true)
    setError("")
    
    try {
      // TODO: Replace with actual API call
      console.log("Login attempt:", data)
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      // Mock successful login
      const mockUser = {
        id: "1",
        name: "John Doe",
        username: data.username,
        email: "john.doe@example.com",
        password: "hidden",
        createdAt: new Date()
      }
      
      const mockToken = "mock-jwt-token"
      
      login(mockUser, mockToken)
      
      toast({
        title: "Welcome back!",
        description: "You have successfully signed in.",
      })
    } catch (err) {
      setError("Invalid username or password")
    } finally {
      setIsLoading(false)
    }
  }

  const handleRegister = async (data: InsertUser) => {
    setIsLoading(true)
    setError("")
    
    try {
      // TODO: Replace with actual API call
      console.log("Registration attempt:", data)
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      // Mock successful registration
      const mockUser = {
        id: "1",
        name: data.name,
        username: data.username,
        email: data.email,
        password: "hidden",
        createdAt: new Date()
      }
      
      const mockToken = "mock-jwt-token"
      
      login(mockUser, mockToken)
      
      toast({
        title: "Account created!",
        description: "Welcome to TaskFlow. You're now signed in.",
      })
    } catch (err) {
      setError("Registration failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        {isLogin ? (
          <LoginForm
            onSubmit={handleLogin}
            onSwitchToRegister={() => {
              setIsLogin(false)
              setError("")
            }}
            isLoading={isLoading}
            error={error}
          />
        ) : (
          <RegisterForm
            onSubmit={handleRegister}
            onSwitchToLogin={() => {
              setIsLogin(true)
              setError("")
            }}
            isLoading={isLoading}
            error={error}
          />
        )}
      </div>
    </div>
  )
}